<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>hf</title>
</head>
<body>

    <!--Könyv hozzáadása-->
    <h2>Könyv hozzáadása</h2>
    <form action="insert.php" method="POST">
        <label for="title">Cím:</label><br>
        <input type="text" id="title" name="title" required><br><br>
        
        <label for="author">Szerző:</label><br>
        <input type="text" id="author" name="author" required><br><br>

        <label for="year">Év:</label><br>
        <input type="number" id="year" name="year" required><br><br>

        <input type="submit" value="Könyv hozzáadása">
    </form> <br>

    <!--Lekérdezések-->
    <h2>Lekérdezés választása</h2>
    <form action="insert.php" method="POST">
        <label for="query">Válassz lekérdezést:</label><br>
        <select name="query" id="query">
            <option value="1">Összes könyv</option>
            <option value="2">Könyvek egy szerzőtől</option>
            <option value="3">Legrégebbi könyv</option>
            <option value="4">Könyvek 1950 után</option>
        </select><br><br>

        <!--Ha "Könyvek egy szerzőtől": új mező a szerző névének beírásához-->
        <div id="szerzoDiv" style="display:none;">
            <label for="szerzoInput">Szerző neve:</label><br>
            <input type="text" id="szerzoInput" name="author"><br><br>
        </div>

        <input type="submit" value="Lekérdezés futtatása">
    </form>

    <script>
        //Ha "Könyvek egy szerzőtől": megjelenik a szerző név mező
        document.getElementById('query').addEventListener('change', function() {
            var szerzoDiv = document.getElementById('szerzoDiv');
            if (this.value == '2') {
                szerzoDiv.style.display = 'block';
            } else {
                szerzoDiv.style.display = 'none';
            }
        });
    </script>

</body>
</html>
