<?php

$servername = "127.0.0.1";
$username = "root";
$password = "";
$databasename = "booksdolg";

try {
    $conn = mysqli_connect($servername, $username, $password, $databasename);

    if (!$conn) {
        throw new Exception(mysqli_connect_error());
    }

    mysqli_set_charset($conn, "utf8");

    if (isset($_POST['query'])) {
        $query = $_POST['query'];
    $author = isset($_POST['author']) ? mysqli_real_escape_string($conn, $_POST['author']) : '';

        switch ($query) {
            //Összes könyv
            case '1':
            $lekerdezes = mysqli_query($conn, "SELECT * FROM books");
            echo "<table border='1'><tr><th>Cím</th><th>Szerző</th><th>Év</th></tr>";
            while ($row = mysqli_fetch_assoc($lekerdezes)) {
                echo "<tr><td>" . $row['title'] . "</td><td>" . $row['author'] . "</td><td>" . $row['year'] . "</td></tr>";
                }
                echo "</table>";
                break;

            //Könyvek egy szerzőtől
            case '2':
                if (!empty($author)) {
                    $lekerdezes2 = mysqli_query($conn, "SELECT title, year FROM books WHERE author = '$author'");
                    echo "<table border='1'><tr><th>Cím</th><th>Év</th></tr>";
                    while ($row = mysqli_fetch_assoc($lekerdezes2)) {
                        echo "<tr><td>" . $row['title'] . "</td><td>" . $row['year'] . "</td></tr>";
                }
                    echo "</table>";
                } else {
                    echo "Add meg egy szerző nevét";
                }
                break;

            //Legrégebbi könyv
            case '3': 
                $lekerdezes3 = mysqli_query($conn, "SELECT title FROM books WHERE year = (SELECT MIN(year) FROM books)");
                $row = mysqli_fetch_assoc($lekerdezes3);
                echo "<p>Legrégebbi könyv: " . $row['title'] . "</p>";
                break;
            
            //Könyvek 1950 után
            case '4':
                $lekerdezes4 = mysqli_query($conn, "SELECT title, author FROM books WHERE year > 1950");
                echo "<table border='1'><tr><th>Cím</th><th>Szerző</th></tr>";
                while ($row = mysqli_fetch_assoc($lekerdezes4)) {
                    echo "<tr><td>" . $row['title'] . "</td><td>" . $row['author'] . "</td></tr>";
                }
                echo "</table>";
                    break;

            default:
                echo "Válassz egy lekérdezést!";
                break;
        }
    }

    //Könyv hozzáadása
    if (isset($_POST['title']) && isset($_POST['author']) && isset($_POST['year'])) {
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $author = mysqli_real_escape_string($conn, $_POST['author']);
        $year = mysqli_real_escape_string($conn, $_POST['year']);

        $tabla_insert = "INSERT INTO books (title, author, year) VALUES ('$title', '$author', $year)";
        if (mysqli_query($conn, $tabla_insert)) {
            echo "<p>Új könyv hozzáadva: $title</p>";
        } else {
            echo "<p>Hiba történt a könyv hozzáadása közben: " . mysqli_error($conn) . "</p>";
        }
    }

} catch (Exception $e) {
    echo $e->getMessage();
}

?>
